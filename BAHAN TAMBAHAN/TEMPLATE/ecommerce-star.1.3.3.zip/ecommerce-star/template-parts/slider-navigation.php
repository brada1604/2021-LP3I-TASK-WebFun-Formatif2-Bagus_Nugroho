<div class="container "> 
	<div class="row">
		<div class="col-sm-4 padding-bottom-md padding-top-md">
			<?php the_widget('ecommerce_star_product_navigation_widget'); ?>
		</div>
		<div class="col-sm-8 padding-bottom-md padding-top-md">
			<?php the_widget('ecommerce_star_product_carousal_widget', 'category_id=0'); ?>
		</div>
	</div>
</div>